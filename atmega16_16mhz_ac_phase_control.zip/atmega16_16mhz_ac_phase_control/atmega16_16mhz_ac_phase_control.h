
#ifndef atmega16_16mhz_ac_phase_control_h
#define atmega16_16mhz_ac_phase_control_h

class atmega16_16mhz_ac_phase_controlClass
{
  public:
        void init();
		void uninit();
		void set_ac_power(int value);
};

extern atmega16_16mhz_ac_phase_controlClass atmega16_16mhz_ac_phase_control;

#endif

