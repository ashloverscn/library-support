/*
this library is intended to be use with atmega16
*/
#include <avr/io.h>
#include <avr/interrupt.h>
#include <Arduino.h>
#include "atmega16_16mhz_ac_phase_control.h"

int pulse = 5;

//int speed[]={360,350,330,300,280,260,240,230,210,200,180,175,165,150,135,125,85,50,20,0};

 void atmega16_16mhz_ac_phase_controlClass::init()
{
  //setup input and output
  
  DDRD &= ~(1 << PD2); //INT0 pin as input for zero cross detect 
  PORTD |= (1 << PD2); //enable pull-up resistor for PD2
  DDRD |= (1 << PD5); //triac gate control pin as output
  
  //setup timer
  
  // set up Timer 
  //(see ATMEGA 16 data sheet for more details)
  //OCR1A = 100;      //initialize the comparator
  TIMSK = 0x14;    //enable comparator A and overflow interrupts
  TCCR1A = 0x00;    //timer control registers set for
  TCCR1B = 0x00;    //normal operation, timer disabled

  //setup interrupt
  
  //PD2 INT0 set up zero crossing interrupt on rising edge
  MCUCR |= (1 << ISC01);
  GICR |= (1 << INT0);
  //enable global interrupt
  sei();
}

 void atmega16_16mhz_ac_phase_controlClass::uninit()
{
  //set default port registers
  DDRD = 0x00;
  PORTD = 0x00;
  //DDRB = 0x00;
  //PORTB = 0x00;
    //clear timer control register
  TIMSK = 0x00;  
  TCCR1A = 0x00;  
  TCCR1B = 0x00; 
  TCNT1 = 0x00;
    //clear interrupt register
  GICR = 0x00;
  MCUCR = 0x00;
  //clear global interrupt
  cli();
}
 void atmega16_16mhz_ac_phase_controlClass::set_ac_power(int value)
 {
	OCR1A = value;//speed[0 to 19] or from 0 to 360 through 400 	 
 }

 ISR(INT0_vect){ //zero cross detect   
  TCCR1B=0x04; //start timer with divide by 256 input
  TCNT1 = 0x00;   //reset timer - count from zero
}

ISR(TIMER1_COMPA_vect){ //comparator match
  PORTD |= (1 << PD5);//set triac gate to high
  TCNT1 = 65536-pulse;      //trigger pulse width
}

ISR(TIMER1_OVF_vect){ //timer1 overflow
  PORTD &= ~(1 << PD5);//turn off triac gate
  TCCR1B = 0x00;          //disable timer stopd unintended triggers
}


atmega16_16mhz_ac_phase_controlClass atmega16_16mhz_ac_phase_control;
