#ifndef analogswitch_h
#define analogswitch_h

class analogswitchClass
{
  public:
  int sw_data(int analog_pin);
    
};

extern analogswitchClass analogswitch;

#endif

