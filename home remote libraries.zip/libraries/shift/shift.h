
#ifndef shift_h
#define shift_h

class shiftClass
{
  public:
        void shift_data(int _8bit, int sck, int data_pin, int reset);
};

extern shiftClass shift;

#endif

