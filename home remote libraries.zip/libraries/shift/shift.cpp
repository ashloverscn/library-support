
#include <avr/eeprom.h>
#include "Arduino.h"
#include "shift.h"

 void shiftClass::shift_data(int _8bit, int sck, int data_pin, int reset)
{
	pinMode(sck,OUTPUT);
  pinMode(data_pin,OUTPUT);
  pinMode(reset,OUTPUT);
  
  digitalWrite(sck,HIGH);
  digitalWrite(data_pin,HIGH);
  digitalWrite(reset,LOW);
  digitalWrite(reset,HIGH);
  
  int temp; 
  
  for(int i=0;i<8;i++)
  {
    temp = _8bit & 0B00000001;
    digitalWrite(data_pin, temp);
    
    digitalWrite(sck,!digitalRead(sck));
    digitalWrite(sck,!digitalRead(sck));
    
    _8bit = (_8bit >> 1);
  }
  
}

shiftClass shift;
