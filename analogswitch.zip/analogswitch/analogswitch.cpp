#include <avr/io.h>
#include <util/delay.h>
#include "Arduino.h"
#include "analogswitch.h"

int analogswitchClass::sw_data(int analog_pin)
{
	int sw_data = 1023 - analogRead(analog_pin);
	
    _delay_us(50);
    
    if(sw_data == 19)
  {
    return(1);
    
      }  

  if(sw_data == 43)
  {
   return(2);
    
      }   

if(sw_data == 68)
  {
   return(3);
    
      }     

if(sw_data == 101)
  {
    return(4);
    
      }  

  if(sw_data == 169)
  {
    return(5);
    
      }   

if(sw_data == 314)
  {
    return(6);
    
      }        
}



analogswitchClass analogswitch;
