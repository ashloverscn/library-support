#include <avr/io.h>
#include <util/delay.h>
#include "Arduino.h"
#include "analogswitch.h"

#define bottom 10/*
#define a 18
#define b 42
#define c 66
#define d 100
#define e 168
#define f 314*/
#define top 400

int analogswitchClass::sw_data(int analog_pin)
{
	int sw_data=0;
	
	if(analogRead(analog_pin) > 900) //for inverted vcc and gnd
	{
		sw_data = 1023 - analogRead(analog_pin);
	}
	else{
		sw_data = analogRead(analog_pin);
	}
	
    _delay_us(50);
	
    if(sw_data <= bottom)
	{
		return(0);
	}
	
	/*##########################################switch assignmnet##########################################################*/
	
    if(sw_data >= bottom && sw_data <= 20)
	{
		return(1);
    }  
	
	if(sw_data >= 30 && sw_data <= 45)
	{
		return(2);
    }
	
	if(sw_data >= 50 && sw_data <= 80)
	{
		return(3);
    }
		
	if(sw_data >= 90 && sw_data <= 110)
	{
		return(4);
    }
	
	if(sw_data >= 120 && sw_data <= 170)
	{
		return(5);
    }
	
	if(sw_data >= 250 && sw_data <= 320)
	{
		return(6);
    }
	
}

analogswitchClass analogswitch;
